#!/bin/bash
sed 's\HOH\WAT\' 4HKD.pdb 
