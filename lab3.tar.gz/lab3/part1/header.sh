#!/bin/bash/

grep -i -v -E  "ATOM\|CONECT\|HETATM\|TER\|END" 4HKD.pdb


