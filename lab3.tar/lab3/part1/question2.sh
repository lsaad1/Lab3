#!/bin/bash/

sed   -e 's/HETATM/ATOM /g' -e 's/MSE/MET/g'  4HKD.pdb




